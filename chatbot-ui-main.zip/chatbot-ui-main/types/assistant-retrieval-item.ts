export interface AssistantRetrievalItem {
  id: string
  name: string
  type: string
}
